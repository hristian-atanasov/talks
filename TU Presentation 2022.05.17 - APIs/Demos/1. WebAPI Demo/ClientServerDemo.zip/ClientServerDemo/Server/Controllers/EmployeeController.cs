﻿using Microsoft.AspNetCore.Mvc;

namespace Server.Controllers
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Department { get; set; }
    }

    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private static List<Employee> employees = new List<Employee>()
        {
            new Employee()
            {
                EmployeeId = 1, Name = "Ivan Ivanov", Address = "Varna", Department = "IT"
            },
            new Employee()
            {
                EmployeeId = 2, Name = "Georgi Georgiev", Address = "Sofia", Department = "HR"
            },
            new Employee()
            {
                EmployeeId = 3, Name = "Petar Petrov", Address = "Plovdiv", Department = "IT"
            },
            new Employee()
            {
                EmployeeId = 4, Name = "Stoyan Stoyanov", Address = "Veliko Tarnovo", Department = "Sales"
            },
            new Employee()
            {
                EmployeeId = 5, Name = "Vasil Vasilev", Address = "Burgas", Department = "HR"
            },
        };

        [HttpGet]
        public IEnumerable<Employee> GetAllEmployees()
        {
            return employees;
        }

        [HttpGet("{id}")]
        public ActionResult GetEmployeeDetails(int id)
        {
            var employee = employees.FirstOrDefault(e => e.EmployeeId == id);
            if (employee is null)
            {
                return NotFound($"Employee with id: {id} not found!");
            }

            return Ok(employee);
        }

        [HttpPost]
        public IActionResult AddEmployee(Employee employee)
        {
            var existingEmployee = employees.FirstOrDefault(e => e.EmployeeId == employee.EmployeeId);
            if (existingEmployee is not null)
            {
                return BadRequest($"Employee with id: {employee.EmployeeId} already exists!");
            }

            employees.Add(employee);
            return Ok();
        }
    }
}
