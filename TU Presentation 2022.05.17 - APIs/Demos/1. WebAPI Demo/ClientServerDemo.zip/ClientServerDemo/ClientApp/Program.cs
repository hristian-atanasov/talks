﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using ClientApp;

var builder = new HostBuilder()
    .ConfigureServices((hostContext, services) =>
    {
        services.AddHttpClient();
        services.AddTransient<EmployeeService>();
    }).UseConsoleLifetime();

var host = builder.Build();

var employeeServiceDemo = new EmployeeServiceDemo(host.Services);

await employeeServiceDemo.PrintAllEmployees();

await employeeServiceDemo.PrintSingleEmployeeById(2);

await employeeServiceDemo.CreateEmployee();

await employeeServiceDemo.PrintAllEmployees();

await host.RunAsync();