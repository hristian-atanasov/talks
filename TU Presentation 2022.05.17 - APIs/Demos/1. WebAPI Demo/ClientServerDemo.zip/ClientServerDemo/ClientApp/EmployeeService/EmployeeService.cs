﻿using Microsoft.Extensions.Options;
using System.Text;
using System.Text.Json;

namespace ClientApp
{
    public class EmployeeService
    {
        private readonly string serviceURL = "https://localhost:7157";
        private readonly IHttpClientFactory httpClientFactory;

        private readonly JsonSerializerOptions jsonSerializerOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        public EmployeeService(IHttpClientFactory httpClientFactory)
        {
            this.httpClientFactory = httpClientFactory;
        }

        public async Task<List<Employee>> GetAll()
        {
            List<Employee> employees = null;

            var requestUri = new StringBuilder();
            requestUri.Append($"{serviceURL}/employee");

            // Call the method Get
            var response = await httpClientFactory.CreateClient().GetAsync(requestUri.ToString());

            // Check the response
            if (response.IsSuccessStatusCode)
            {
                // Read the list of Users
                var responseContent = await response.Content.ReadAsStringAsync();
                employees = JsonSerializer.Deserialize<List<Employee>>(responseContent, jsonSerializerOptions);
            }

            return employees;
        }

        public async Task<Employee> GetById(int id)
        {
            Employee employee = null;

            var requestUri = new StringBuilder();
            requestUri.Append(serviceURL);
            requestUri.Append($"/employee/{id}");

            // Call the method Get
            var response = await httpClientFactory.CreateClient().GetAsync(requestUri.ToString());

            // Check the response
            if (response.IsSuccessStatusCode)
            {
                // Read the list of Users
                var responseContent = await response.Content.ReadAsStringAsync();
                employee = JsonSerializer.Deserialize<Employee>(responseContent, jsonSerializerOptions);
            }

            return employee;
        }

        public async Task<bool> Create(Employee employee)
        {
            var requestUri = new StringBuilder();
            requestUri.Append($"{serviceURL}/employee");

            // Prepare content
            var content = new StringContent(JsonSerializer.Serialize(employee), Encoding.UTF8, "application/json");

            // Call the method Post
            var response = await httpClientFactory.CreateClient().PostAsync(requestUri.ToString(), content);

            return response.IsSuccessStatusCode;
        }
    }
}
