﻿using Microsoft.Extensions.DependencyInjection;

namespace ClientApp
{
    public class EmployeeServiceDemo
    {
        private IServiceProvider _services;

        public EmployeeServiceDemo(IServiceProvider services)
        {
            _services = services;
        }

        public async Task PrintAllEmployees()
        {
            Console.WriteLine("List all employees...");

            try
            {
                var employeeService = _services.GetRequiredService<EmployeeService>();
                var employees = await employeeService.GetAll();

                foreach (var item in employees)
                {
                    Console.WriteLine($"Employee {item.EmployeeId} - {item.Name} - {item.Address} - {item.Department}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();
        }

        public async Task PrintSingleEmployeeById(int id)
        {
            Console.WriteLine($"List employee details with Id: {id}");

            try
            {
                var employeeService = _services.GetRequiredService<EmployeeService>();
                var employee = await employeeService.GetById(id);

                Console.WriteLine($"Employee: {employee.EmployeeId} - {employee.Name} - {employee.Address} - {employee.Department}");
                Console.WriteLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();
        }

        public async Task CreateEmployee()
        {
            Employee employee = new Employee()
            {
                EmployeeId = 101,
                Name = "Employee 1",
                Address = "Tsar Osvoboditel",
                Department = "Marketing"
            };

            Console.WriteLine("Creating new employee...");

            try
            {
                var employeeService = _services.GetRequiredService<EmployeeService>();
                bool result = await employeeService.Create(employee);

                Console.WriteLine($"Result: {result}");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.WriteLine();
        }
    }
}
